import React from 'react'

export default function Loading() {
    return <div className="font-display uppercase text-3xl m-auto flex justify-center items-center min-h-screen">Cargando...</div>;
}
